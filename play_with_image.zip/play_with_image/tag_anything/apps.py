from django.apps import AppConfig


class TagAnythingConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'tag_anything'
    verbose_name = 'Тегай что угодно'
